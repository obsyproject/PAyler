/*
 * Copyright (C) 2026 InterTune
 *
 * SPDX-License-Identifier: GPL-3.0
 */

package com.dd3boh.outertune.engine

import java.sql.Connection
import java.time.ZoneId

/** The engine's input read over JDBC from a version 21 database, the way the loader reads it from Room. */
object JdbcEngineInput {
    private fun Connection.rows(sql: String): List<Map<String, Any?>> = createStatement().use { st ->
        st.executeQuery(sql).use { rs ->
            val cols = (1..rs.metaData.columnCount).map { rs.metaData.getColumnName(it) }
            buildList { while (rs.next()) add(cols.associateWith { rs.getObject(it) }) }
        }
    }

    fun songs(db: Connection, zone: ZoneId = ZoneId.systemDefault()): Map<String, SongRow> =
        db.rows(EngineSql.SONGS).associate { r ->
            val id = r["id"] as String
            val liked = (r["liked"] as Number).toInt() != 0
            val likedDate = (r["likedDate"] as Number?)?.toLong()
            id to SongRow(id, r["title"] as String, r["artistId"] as String?, r["artistName"] as String?, liked,
                likedDate?.takeIf { liked }?.let { storedLocalToInstant(it, zone) }, r["inLibrary"] != null, (r["isLocal"] as Number).toInt() != 0)
        }

    /** As the app's loader reads them: open rows ending [now], failed plays left out (EngineListens.forBuild). */
    fun listens(db: Connection, now: Long): List<ListenRow> = EngineListens.forBuild(
        db.rows("SELECT songId, startedAt, endedAt, playedMs, durationMs, endReason, origin, autoplayDepth, sessionId, tzOffsetMin, learn, runId, queueId, impressionId, contextChip FROM listen").map {
            val endReason = (it["endReason"] as Number).toInt()
            ListenRow(it["songId"] as String, (it["startedAt"] as Number).toLong(), (it["endedAt"] as Number).toLong(),
                (it["playedMs"] as Number).toLong(), (it["durationMs"] as Number).toLong(), endReason, (it["origin"] as Number).toInt(),
                (it["autoplayDepth"] as Number).toInt(), (it["sessionId"] as Number).toLong(), (it["tzOffsetMin"] as Number).toInt(), (it["learn"] as Number).toInt() != 0,
                (it["runId"] as Number).toLong(), (it["queueId"] as Number).toLong(), (it["impressionId"] as Number?)?.toLong(), (it["contextChip"] as Number).toInt())
        },
        now,
    )

    /** YouTube's edges through the app's query, so a copy holding Last.fm's too reads the same as the app on YouTube. */
    fun edges(db: Connection, source: Int = 0): List<Edge> =
        db.rows(com.dd3boh.outertune.db.RelatedSql.ENGINE_EDGES.replace(":source", "$source")).map(::edgeOf)

    /** Both sources merged, one edge per pair with its provenance bits, as the app reads them for Both. */
    fun edgesAll(db: Connection): List<Edge> = db.rows(com.dd3boh.outertune.db.RelatedSql.ENGINE_EDGES_ALL).map(::edgeOf)

    private fun edgeOf(r: Map<String, Any?>) = Edge(r["songId"] as String, r["relatedSongId"] as String, (r["sources"] as Number).toInt())

    fun links(db: Connection): List<VersionLink> = db.rows("SELECT songId, versionId FROM song_version_map").map { VersionLink(it["songId"] as String, it["versionId"] as String) }

    fun load(db: Connection, now: Long, tzOffsetMin: Int = 0): EngineInput {
        val listens = listens(db, now)
        return EngineInput(now, songs(db), listens, edges(db), links(db), bucket = dayPartBucket(now, tzOffsetMin), tzOffsetMin = tzOffsetMin)
    }
}
