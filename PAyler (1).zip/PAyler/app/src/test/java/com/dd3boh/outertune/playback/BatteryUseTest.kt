/*
 * Copyright (C) 2026 InterTune
 *
 * SPDX-License-Identifier: GPL-3.0
 */

package com.dd3boh.outertune.playback

import com.dd3boh.outertune.constants.AudioQuality
import com.dd3boh.outertune.constants.BatteryMode
import com.dd3boh.outertune.constants.BatteryMode.BALANCED
import com.dd3boh.outertune.constants.BatteryMode.FULL
import com.dd3boh.outertune.constants.BatteryMode.SAVER
import com.dd3boh.outertune.constants.PlayerBackgroundStyle
import com.dd3boh.outertune.constants.SpatialAudioMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * What each choice of Battery use turns down, and that none of them takes a setting away.
 *
 * His answers of 24 Oct 2026: Balanced is everyone's default, Saver turns the sound effects off
 * and streams at Low quality on mobile data. The rest is as experiments/features/battery-1023/MODES.md
 * has it. A mode is a rule applied where a setting is used: the person's own value goes in and
 * the value to use comes out, so what was set is never written over, and Full and Balanced give
 * every setting back exactly as it was chosen.
 */
class BatteryUseTest {

    private val modes = BatteryMode.entries

    @Test
    fun `a mode never chosen is Balanced, on a new install and on one that updated`() {
        // An update has no key for it either: nothing is written, so it reads as the default.
        assertEquals(BALANCED, BatteryUse.modeOf(null, null, phoneSaver = false, offered = true))
        assertEquals(BALANCED, BatteryUse.DEFAULT)
        // A name this build does not know, from a backup made by a newer one, is the default too.
        assertEquals(BALANCED, BatteryUse.modeOf("TURBO", null, phoneSaver = false, offered = true))
        for (mode in modes) assertEquals(mode, BatteryUse.modeOf(mode.name, null, phoneSaver = false, offered = true))
    }

    @Test
    fun `a build that does not offer the choice runs as Full, whatever is stored`() {
        for (stored in listOf(null, "BALANCED", "SAVER", "FULL")) for (follow in listOf(null, true, false)) for (phone in listOf(true, false)) {
            assertEquals(FULL, BatteryUse.modeOf(stored, follow, phone, offered = false))
        }
        for (mode in modes) for (phone in listOf(true, false)) {
            assertEquals(FULL, BatteryUse.inForce(mode, follow = true, phoneSaver = phone, offered = false))
            assertEquals(mode, BatteryUse.inForce(mode, follow = false, phoneSaver = phone, offered = true))
        }
    }

    @Test
    fun `Full is the app as it was before the choice`() {
        assertEquals(30 * 60L, BatteryUse.syncEverySeconds(FULL))
        assertTrue(BatteryUse.syncAllowed(FULL, metered = true))
        assertEquals(5 * 60 * 1000L, BatteryUse.tasteKeptMs(FULL))
        assertEquals(BatteryUse.Bars.SCREEN_RATE, BatteryUse.bars(FULL))
        assertFalse("no offload unless the developer's switch asks for it", BatteryUse.offload(FULL, developerSwitch = false, needsAppPath = false, outputSafe = true))
        assertTrue(BatteryUse.offload(FULL, developerSwitch = true, needsAppPath = false, outputSafe = true))
        assertEquals(0, BatteryUse.songCacheMb(null, FULL))
    }

    @Test
    fun `Balanced syncs every two hours, keeps the taste half an hour and steps the bars thirty times a second`() {
        assertEquals(2 * 60 * 60L, BatteryUse.syncEverySeconds(BALANCED))
        assertTrue(BatteryUse.syncAllowed(BALANCED, metered = true))
        assertEquals(30 * 60 * 1000L, BatteryUse.tasteKeptMs(BALANCED))
        assertEquals(BatteryUse.Bars.STEPPED, BatteryUse.bars(BALANCED))
        assertEquals("thirty steps a second", 33L, BatteryUse.BARS_STEP_MS)
        assertFalse(BatteryUse.offload(BALANCED, developerSwitch = false, needsAppPath = false, outputSafe = true))
        assertFalse(BatteryUse.holdsEffects(BALANCED))
    }

    @Test
    fun `Saver syncs on Wi-Fi only, every six hours, and keeps the taste an hour`() {
        assertEquals(6 * 60 * 60L, BatteryUse.syncEverySeconds(SAVER))
        assertFalse("not on mobile data", BatteryUse.syncAllowed(SAVER, metered = true))
        assertTrue(BatteryUse.syncAllowed(SAVER, metered = false))
        assertEquals(60 * 60 * 1000L, BatteryUse.tasteKeptMs(SAVER))
        assertEquals(BatteryUse.Bars.STILL, BatteryUse.bars(SAVER))
    }

    @Test
    fun `a new run takes a taste no older than Full keeps it, so a radio's picks stay fresh`() {
        // Only the taste knows what was just heard in another queue; the run's own songs and skips
        // count at once whatever its age.
        for (mode in modes) {
            assertEquals(BatteryUse.tasteKeptMs(FULL), BatteryUse.tasteKeptMs(mode, sameRun = false))
            assertEquals(BatteryUse.tasteKeptMs(mode), BatteryUse.tasteKeptMs(mode, sameRun = true))
        }
    }

    @Test
    fun `Saver turns the sound effects off`() {
        assertTrue(BatteryUse.holdsEffects(SAVER))
        for (chosen in SpatialAudioMode.entries) assertEquals(SpatialAudioMode.OFF, BatteryUse.spatialAudio(chosen, SAVER))
        assertFalse(BatteryUse.fade(true, SAVER))
        assertFalse("its scan runs while music plays", BatteryUse.proximity(true, SAVER))
        assertEquals("no boost past 100%", 1f, BatteryUse.volume(2.5f, SAVER))
        assertEquals("below 100% the volume is as set", 0.4f, BatteryUse.volume(0.4f, SAVER))
    }

    @Test
    fun `Saver asks for the low-power path whenever nothing needs the app's own`() {
        assertTrue(BatteryUse.offload(SAVER, developerSwitch = false, needsAppPath = false, outputSafe = true))
        // Skip silence, another speed, a sleep timer counting down: the song stays on the app's path.
        for (mode in modes) for (switch in listOf(true, false)) {
            assertFalse("$mode, switch $switch", BatteryUse.offload(mode, switch, needsAppPath = true, outputSafe = true))
        }
    }

    @Test
    fun `Saver keeps the low-power path off USB headphones, a switch turned on by hand does not (#90)`() {
        // A Pixel 11 with USB headphones went silent after half a minute with the screen off, and
        // stayed silent until they were plugged in again.
        assertFalse(BatteryUse.offload(SAVER, developerSwitch = false, needsAppPath = false, outputSafe = false))
        for (mode in modes) assertTrue("$mode", BatteryUse.offload(mode, developerSwitch = true, needsAppPath = false, outputSafe = false))
        assertFalse(BatteryUse.offload(SAVER, developerSwitch = true, needsAppPath = true, outputSafe = false))
    }

    @Test
    fun `Saver takes Low on mobile data where Audio quality is Auto, and everything is as chosen on Wi-Fi`() {
        assertEquals(AudioQuality.LOW, BatteryUse.quality(AudioQuality.AUTO, metered = true, SAVER))
        for (chosen in AudioQuality.entries) assertEquals(chosen, BatteryUse.quality(chosen, metered = false, SAVER))
        // Low is Low already. Only Auto is lowered: it is the app's own pick, which Saver says how little to spend on.
        assertEquals(setOf(AudioQuality.AUTO), AudioQuality.entries.filter { BatteryUse.lowersQuality(it, SAVER) }.toSet())
        assertTrue(AudioQuality.entries.none { BatteryUse.lowersQuality(it, FULL) || BatteryUse.lowersQuality(it, BALANCED) })
    }

    @Test
    fun `High and Highest are never lowered, in any mode on any network (#88, sometimes it gets so bad)`() {
        // The phone's battery saver turns Saver on by itself, and used to take High down to the smallest stream
        // (about 50 kbps) on mobile data without a word, while no other app did.
        for (chosen in listOf(AudioQuality.HIGH, AudioQuality.MAX)) {
            for (mode in modes) for (metered in listOf(true, false)) {
                assertEquals("$chosen in $mode, metered $metered", chosen, BatteryUse.quality(chosen, metered, mode))
            }
            assertFalse("$chosen: no line under Audio quality says it is lowered", BatteryUse.lowersQuality(chosen, SAVER))
        }
        // and Low stays Low
        for (mode in modes) for (metered in listOf(true, false)) assertEquals(AudioQuality.LOW, BatteryUse.quality(AudioQuality.LOW, metered, mode))
    }

    @Test
    fun `Saver downloads on Wi-Fi only and draws Blur in place of Living blur`() {
        assertTrue(BatteryUse.downloadsOnWifiOnly(false, SAVER))
        val blur = PlayerBackgroundStyle.BLUR
        assertEquals(blur, BatteryUse.playerBackground(PlayerBackgroundStyle.LIVING, SAVER, blur))
        // Where the phone has no blur, the fallback it is given: the gradient.
        assertEquals(PlayerBackgroundStyle.GRADIENT, BatteryUse.playerBackground(PlayerBackgroundStyle.LIVING, SAVER, PlayerBackgroundStyle.GRADIENT))
        for (chosen in PlayerBackgroundStyle.entries - PlayerBackgroundStyle.LIVING) {
            assertEquals(chosen, BatteryUse.playerBackground(chosen, SAVER, blur))
        }
    }

    @Test
    fun `Full and Balanced give every setting back exactly as it was chosen`() {
        // So leaving Saver brings back every effect, quality and style as it was set: nothing of it
        // was written over.
        for (mode in listOf(FULL, BALANCED)) {
            for (chosen in SpatialAudioMode.entries) assertEquals(chosen, BatteryUse.spatialAudio(chosen, mode))
            for (chosen in listOf(true, false)) {
                assertEquals(chosen, BatteryUse.fade(chosen, mode))
                assertEquals(chosen, BatteryUse.proximity(chosen, mode))
                assertEquals(chosen, BatteryUse.downloadsOnWifiOnly(chosen, mode))
            }
            for (volume in listOf(0f, 0.5f, 1f, 2.5f, 4f)) assertEquals(volume, BatteryUse.volume(volume, mode))
            for (chosen in AudioQuality.entries) for (metered in listOf(true, false)) {
                assertEquals(chosen, BatteryUse.quality(chosen, metered, mode))
            }
            for (chosen in PlayerBackgroundStyle.entries) assertEquals(chosen, BatteryUse.playerBackground(chosen, mode, PlayerBackgroundStyle.BLUR))
            for (stored in listOf(null, 0, 128, 512, 4096, -1)) assertEquals(stored ?: 0, BatteryUse.songCacheMb(stored, mode))
        }
    }

    @Test
    fun `a setting set by hand is kept in every mode`() {
        // Download on Wi-Fi only, turned on by hand, stays on whatever the mode.
        for (mode in modes) assertTrue(BatteryUse.downloadsOnWifiOnly(true, mode))
        // A song cache size picked by hand wins over Saver's, Off and Unlimited included: Saver
        // only fills the gap where none was ever picked.
        for (stored in listOf(0, 128, 1024, -1)) assertEquals(stored, BatteryUse.songCacheMb(stored, SAVER))
        assertEquals(BatteryUse.SAVER_SONG_CACHE_MB, BatteryUse.songCacheMb(null, SAVER))
        assertEquals("one of the sizes the setting offers", 512, BatteryUse.SAVER_SONG_CACHE_MB)
        // The developer's Enable offload stays on in every mode.
        for (mode in modes) assertTrue(BatteryUse.offload(mode, developerSwitch = true, needsAppPath = false, outputSafe = true))
        // An effect switched off by hand stays off.
        for (mode in modes) {
            assertFalse(BatteryUse.fade(false, mode))
            assertEquals(SpatialAudioMode.OFF, BatteryUse.spatialAudio(SpatialAudioMode.OFF, mode))
        }
    }

    @Test
    fun `each mode does less than the one before it`() {
        assertTrue(BatteryUse.syncEverySeconds(FULL) < BatteryUse.syncEverySeconds(BALANCED))
        assertTrue(BatteryUse.syncEverySeconds(BALANCED) < BatteryUse.syncEverySeconds(SAVER))
        assertTrue(BatteryUse.tasteKeptMs(FULL) < BatteryUse.tasteKeptMs(BALANCED))
        assertTrue(BatteryUse.tasteKeptMs(BALANCED) < BatteryUse.tasteKeptMs(SAVER))
        assertEquals(listOf(FULL, BALANCED, SAVER), modes)
    }

    // Round two, his word of 25 Oct 2026.

    @Test
    fun `the phone's battery saver runs the app as Saver while the switch lets it, in every combination`() {
        assertTrue("on for everyone", BatteryUse.FOLLOW_PHONE_DEFAULT)
        for (picked in modes) for (follow in listOf(true, false)) for (phone in listOf(true, false)) {
            val expected = if (follow && phone) SAVER else picked
            assertEquals("$picked, switch $follow, phone saver $phone", expected, BatteryUse.effective(picked, follow, phone))
            assertEquals(expected, BatteryUse.modeOf(picked.name, follow, phone, offered = true))
            assertEquals(expected, BatteryUse.inForce(picked, follow, phone, offered = true))
            // The note under the switch only when the phone is what turned Saver on.
            assertEquals(follow && phone && picked != SAVER, BatteryUse.saverFromPhone(picked, follow, phone))
        }
        // A switch never set follows the phone.
        for (picked in modes) assertEquals(SAVER, BatteryUse.modeOf(picked.name, null, phoneSaver = true, offered = true))
        // Nothing stored and the phone's saver on: Saver; off again: Balanced, as nothing was written.
        assertEquals(SAVER, BatteryUse.modeOf(null, null, phoneSaver = true, offered = true))
        assertEquals(BALANCED, BatteryUse.modeOf(null, null, phoneSaver = false, offered = true))
    }

    @Test
    fun `Saver shows a black dark theme, as Android's own battery saver does, and gives the theme back after`() {
        for (chosen in listOf(true, false)) {
            assertTrue("dark even where light was picked", BatteryUse.darkTheme(chosen, SAVER))
            assertTrue(BatteryUse.pureBlack(chosen, SAVER))
            for (mode in listOf(FULL, BALANCED)) {
                assertEquals(chosen, BatteryUse.darkTheme(chosen, mode))
                assertEquals(chosen, BatteryUse.pureBlack(chosen, mode))
            }
        }
    }

    @Test
    fun `Saver keeps the glass still and asks for thirty frames a second`() {
        assertTrue(BatteryUse.glassStill(SAVER))
        assertTrue(BatteryUse.lowFrameRate(SAVER))
        for (mode in listOf(FULL, BALANCED)) {
            assertFalse(BatteryUse.glassStill(mode))
            assertFalse(BatteryUse.lowFrameRate(mode))
        }
        assertEquals(30f, BatteryUse.SAVER_FRAME_RATE)
    }

    @Test
    fun `Saver holds the window to the slowest mode at the same size that is still at least 30 Hz`() {
        fun m(id: Int, hz: Float, w: Int = 1080, h: Int = 2340) = BatteryUse.ScreenMode(id, w, h, hz)
        // A Pixel 5: 60 and 90.
        assertEquals(1, BatteryUse.saverScreenMode(listOf(m(1, 60f), m(2, 90f)), m(2, 90f))?.id)
        // The same while the system happens to be at 60 already: the hold is what keeps it from
        // going back up to 90 on the next scroll.
        assertEquals(1, BatteryUse.saverScreenMode(listOf(m(1, 60f), m(2, 90f)), m(1, 60f))?.id)
        // 60, 90 and 120, and one at another size that is never taken.
        assertEquals(4, BatteryUse.saverScreenMode(listOf(m(3, 120f), m(4, 60f), m(5, 90f), m(6, 30f, 720, 1560)), m(3, 120f))?.id)
        // A panel with a 30 Hz mode, and one under 30 that is left out.
        assertEquals(8, BatteryUse.saverScreenMode(listOf(m(7, 120f), m(8, 30f), m(9, 24f)), m(7, 120f))?.id)
        // A 29.97 Hz mode counts as 30.
        assertEquals(10, BatteryUse.saverScreenMode(listOf(m(10, 29.97f), m(11, 60f)), m(11, 60f))?.id)
        // One rate at this size: nothing to hold back, the window only hints the rate.
        assertEquals(null, BatteryUse.saverScreenMode(listOf(m(12, 60f)), m(12, 60f)))
        assertEquals(null, BatteryUse.saverScreenMode(listOf(m(13, 60f), m(14, 24f)), m(13, 60f)))
        assertEquals(null, BatteryUse.saverScreenMode(listOf(m(15, 60f), m(16, 120f, 1440, 3120)), m(15, 60f)))
    }

    @Test
    fun `Home's engine rows, Full as before, Balanced at most every three hours when enough changed, Saver on a pull only`() {
        val hour = 3_600_000L
        // Full: a new session, a new part of the day or three hours.
        assertTrue(BatteryUse.rowStands(FULL, hour, sameSession = true, sameDayPart = true, listensSince = 50))
        assertFalse(BatteryUse.rowStands(FULL, hour, sameSession = false, sameDayPart = true, listensSince = 0))
        assertFalse(BatteryUse.rowStands(FULL, hour, sameSession = true, sameDayPart = false, listensSince = 0))
        assertFalse(BatteryUse.rowStands(FULL, 3 * hour, sameSession = true, sameDayPart = true, listensSince = 0))
        // Balanced: under three hours it stands whatever happened.
        for (session in listOf(true, false)) for (part in listOf(true, false)) {
            assertTrue(BatteryUse.rowStands(BALANCED, 3 * hour - 1, session, part, listensSince = 500))
        }
        // After three hours, only enough listens or a day gone by builds it again.
        assertTrue(BatteryUse.rowStands(BALANCED, 5 * hour, sameSession = false, sameDayPart = false, listensSince = BatteryUse.ROWS_REBUILD_LISTENS - 1))
        assertFalse(BatteryUse.rowStands(BALANCED, 5 * hour, sameSession = true, sameDayPart = true, listensSince = BatteryUse.ROWS_REBUILD_LISTENS))
        assertFalse(BatteryUse.rowStands(BALANCED, BatteryUse.ROWS_OLD_MS, sameSession = true, sameDayPart = true, listensSince = 0))
        // Saver: until a pull to refresh, which the caller builds on.
        assertTrue(BatteryUse.rowStands(SAVER, 30 * 24 * hour, sameSession = false, sameDayPart = false, listensSince = 10_000))
        assertFalse(BatteryUse.buildsUnseenRows(SAVER))
        assertFalse(BatteryUse.rowFollowsSession(SAVER))
        for (mode in listOf(FULL, BALANCED)) {
            assertTrue(BatteryUse.buildsUnseenRows(mode))
            assertTrue(BatteryUse.rowFollowsSession(mode))
        }
    }
}
